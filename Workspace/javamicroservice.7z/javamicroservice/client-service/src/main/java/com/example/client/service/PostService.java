package com.example.client.service;

import com.example.client.model.Posts;

import java.util.List;

public interface PostService {

	List<Posts> getAllPosts();

}
